/*
 * UART_TestBench.c
 *
 * Created: 6/25/2019 4:47:17 PM
 *  Author: Lovish Mehta
 */ 


// used for refrence of pointers http://www.cs.fsu.edu/~myers/cgs4406/notes/pointers.html

//                                           For UART 0 commands are as following

// In this library you can print "Single characters" , "Strings" and "Numbers" using the function   => usart_print(data)
// If you want to write data to some sensor you can use the function                                => usart_write(data)
// If you want to Receive some data you can use the function                                        => usart_receive()
// If you want to wait for the Rx buffer to get filled you can use function                         => usart_available()
// To initialize the usart you can use the function                                                 => usart_init(baud rate)

//                                           For UART 1 commands are as following

// In this library you can print "Single characters" , "Strings" and "Numbers" using the function   => usart1_print(data)
// If you want to write data to some sensor you can use the function                                => usart1_write(data)
// If you want to Receive some data you can use the function                                        => usart1_receive()
// If you want to wait for the Rx buffer to get filled you can use function                         => usart1_available()
// To initialize the usart you can use the function                                                 => usart1_init(baud rate)

//                                           For UART 2 commands are as following

// In this library you can print "Single characters" , "Strings" and "Numbers" using the function   => usart2_print(data)
// If you want to write data to some sensor you can use the function                                => usart2_write(data)
// If you want to Receive some data you can use the function                                        => usart2_receive()
// If you want to wait for the Rx buffer to get filled you can use function                         => usart2_available()
// To initialize the usart you can use the function                                                 => usart2_init(baud rate)

//                                           For UART 3 commands are as following

// In this library you can print "Single characters" , "Strings" and "Numbers" using the function   => usart3_print(data)
// If you want to write data to some sensor you can use the function                                => usart3_write(data)
// If you want to Receive some data you can use the function                                        => usart3_receive()
// If you want to wait for the Rx buffer to get filled you can use function                         => usart3_available()
// To initialize the usart you can use the function                                                 => usart3_init(baud rate)

#ifndef UART_TestBench_h
#define UART_TestBench_h

void usart_init(uint16_t baud);
void usart1_init(uint16_t baud);
void usart2_init(uint16_t baud);
void usart3_init(uint16_t baud);



/////////////////////////////////////////////// // This function is used to print single character // ////////////////////////////////////////////

void usart_print(char num); 
void usart1_print(char num);
void usart2_print(char num);
void usart3_print(char num) ;                


//////////////////// // This Function is used to print String (address of first element of string gets passed as the /////////////////////////// 
/////////////////// //  argument when we pass the String i.e usart_print("Hello"), here address of 'H' get passed. ///////////////////////////

void usart_print(char str[]);
void usart1_print(char str[]);
void usart2_print(char str[]);                      
void usart3_print(char str[]);

// NOTE: This function doesnot work properly, only 1st integer gets printed e.g. usart_print(76) => only 7 gets printed.

///////////////////////// This function is used to print single  Numbers or we can say Integers // //////////////////////////////////////////////

void usart_print(int num); 
void usart1_print(int num);     
void usart2_print(int num);     
void usart3_print(int num);                       



uint8_t usart_available();
uint8_t usart1_available();
uint8_t usart2_available();
uint8_t usart3_available();
 
void usart_write(int num);
void usart1_write(int num);
void usart2_write(int num);
void usart3_write(int num);


#endif
